package pdf_����;

public class Printer {

	int num;
	boolean t;
	double dou;
	String str;

	void println(int num) {
		System.out.println(num);
	}
	void println(boolean t) {
		System.out.println(t);
	}
	void println(double dou) {
		System.out.println(dou);
	}
	void println(String str) {
		System.out.println(str);
	}
	
}
