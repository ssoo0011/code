package static_0;

public class StraticSample {
	
	public int n;
	public void g() {
		m = 20;
	}
	public void h(){ //�Ϲ� �ɹ�
		m = 30;
	}
	
	public static int m;
	public static void f() {//����ƽ�ɹ�
		m = 5;
	}
}
