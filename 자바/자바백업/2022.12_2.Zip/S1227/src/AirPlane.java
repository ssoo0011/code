
public abstract class AirPlane {

	public abstract String getPrice();
	public abstract String getBrand();
	public abstract String getName();
	

}
