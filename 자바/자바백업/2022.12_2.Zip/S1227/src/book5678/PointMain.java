package book5678;

public class PointMain {

	public static void main(String[] args) {
		
//		ColorPoint cp = new ColorPoint(5, 5, "YELLO");
//		cp.setXY(10, 20);
//		cp.setColor("RED");
//		String string = cp.toString();
//		
//		System.out.println(string + "�Դϴ�.");

		ColorPoint zero = new ColorPoint();
		System.out.println(zero.toString() + "�Դϴ�.");
		
		ColorPoint cp2 = new ColorPoint(10, 10);
		cp2.setXY(5, 5);
		cp2.setColor("Yellow");
		System.out.println(cp2.toString());
		
		
	}

}
