package book12;

public class TvMain{

	public static void main(String[] args) {
		
		ColorTv mytv = new ColorTv(32, 1024);
		mytv.printProperty();
		IPTV iptv = new IPTV("192.1.1.2", 32, 2048);
		iptv.printProperty();

	}

}
