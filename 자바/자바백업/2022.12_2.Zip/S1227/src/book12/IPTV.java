package book12;

public class IPTV extends ColorTv{

	String adress;
	
	public IPTV(String adress, int size, int color) {
		super(size, color);

		this.adress = adress;
	}
	
	public void printProperty(){
		
		System.out.println("���� IPTV�� "+ adress + "�ּ��� "+ getSize() + "��ġ" + color + "�÷�");
	}
}
