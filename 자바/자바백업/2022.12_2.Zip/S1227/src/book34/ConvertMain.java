package book34;

public class ConvertMain {

	public static void main(String[] args) {
		
//		Won2Dollar toDollar = new Won2Dollar(1200);
//		toDollar.run();
//		
		Km2Mile toMile = new Km2Mile(1.6);
		toMile.run();

	}

}
