package book34;

public class Km2Mile extends Converter {
	
	public Km2Mile(double km) {
		ratio = km;
	}

	protected double convert(double src) {
		return src / ratio;
	}
	protected String getSrcString() {
		return "km";
	}
	protected String getDestString() {
		return "mile";
	}
	protected double ratio;
}
