package book34;

public class Won2Dollar extends Converter{
	
	public Won2Dollar(int won) {
		ratio = won;
	}

	protected double convert(double src) {
		return src / ratio;
	}
	protected String getSrcString() {
		return "��";
	}
	protected String getDestString() {
		return "�޷�";
	}
	protected double ratio; 
}
