package upcasting1;

public class President1 extends Person1 {
	
	int salary;
	String nation;

}
