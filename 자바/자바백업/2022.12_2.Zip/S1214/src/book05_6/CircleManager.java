package book05_6;

import java.util.Scanner;

public class CircleManager {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		Circle c[] = new Circle[2];
		
		for (int i = 0; i < c.length; i++) {
			System.out.println("x, y, radius >>");
			double x = scanner.nextDouble();
			double y = scanner.nextDouble();
			int radius = scanner.nextInt();
			
			c[i] = new Circle(x, y, radius);
			
		}
//		for (int i = 0; i < c.length; i++) {
//			c[i].show();
//		}
		
		double max = c[0].maxcir(); //c[0]�� ������ ���� �޾ƿ��� ���� max
		int rad = 0;
		
		for (int i = 0; i < c.length; i++) {
			if(max < c[i].maxcir()) {
				max = c[i].maxcir();
				rad = i;
			}
		}
		c[rad].show();
		

	}

}
