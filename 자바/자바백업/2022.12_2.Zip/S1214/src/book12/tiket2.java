package book12;

import java.util.Scanner;

public class tiket2 {
	String [] S = new String[10];
	String [] A = new String[10];
	String [] B = new String[10];
	Scanner scanner = new Scanner(System.in);

	public void array() { // �迭�� --- �־��ֱ�
		for (int i = 0; i < A.length; i++) {
			S[i] = "---";
			A[i] = "---";
			B[i] = "---";
		}
	}
	
	public int menu() { //�޴� ��ȣ ����

		System.out.print("���� : 1, ��ȸ : 2, ��� : 3, ������ : 4 >>");
		int a = scanner.nextInt();
		return a;
		
	}
	
	public void sit() { //�¼� ���� �����ִ� �޼ҵ�

		
		System.out.println("�¼� ���� S : 1, A : 2, B: 3 >>");
		int nowsit = scanner.nextInt();
		scanner.nextLine();
		
		if(nowsit == 1) {
			System.out.print("S>> ");
			for (int i = 0; i < A.length; i++) {
				System.out.print(S[i] + " ");
			}
			name(nowsit);
		}else if(nowsit == 2) {
			System.out.print("A>> ");
			for (int i = 0; i < A.length; i++) {
					System.out.print(A[i] + " ");
				}name(nowsit);
			
		}else if(nowsit == 3) {
			System.out.print("B>> ");
			for (int i = 0; i < B.length; i++) {
				System.out.print(A[i] + " ");
			}name(nowsit);
		}
	}
	
	public void name(int nowsit) {//�̸�/ �¼� �ڸ� �ִ� ����
		
		
		System.out.println();
		System.out.print("�̸� >>");
		String name1 = scanner.nextLine();
		System.out.print("��ȣ >>");
		int sitnum1 = scanner.nextInt();
		
		if(nowsit == 1) {
			System.out.print("S>> ");
			for (int i = 0; i < S.length; i++) {
				S[sitnum1-1] = name1;
				System.out.print(S[i] + " ");
			}
			
		}else if(nowsit == 2) {
			System.out.print("A>> ");
			for (int i = 0; i < A.length; i++) {
				A[sitnum1-1] = name1;
				System.out.print(A[i] + " ");
			}
			
		}else if(nowsit == 3) {
			System.out.print("B>> ");
			for (int i = 0; i < B.length; i++) {
				B[sitnum1-1] = name1;
				System.out.print(B[i] + " ");
			}
		}
		
	}public void Info() { //�¼� ���� ���� (��ȸ)
		
		System.out.print("S >> ");
		for (int i = 0; i < S.length; i++) {
			System.out.print(S[i] + " ");
		}System.out.println();
		System.out.print("A >> ");
		for (int i = 0; i < A.length; i++) {
			System.out.print(A[i] + " ");
		}System.out.println();
		System.out.print("B >> ");
		for (int i = 0; i < B.length; i++) {
			System.out.print(B[i] + " ");
		}
	}
	
	public void cancle(int sit) { //�¼� ��ȣ, �̸� �Է¹ް� ���

		System.out.println();
		System.out.println("����Ͻ� �������� ������ �Է��ϼ���");
		String name = scanner.nextLine();
		if(sit == 1) {
			for (int i = 0; i < S.length; i++) {
				if(S[i].equals(name)) {
					S[i] = "---";
				}
			}
		}
		if(sit == 2) {
			for (int i = 0; i < A.length; i++) {
				if(A[i].equals(name)) {
					A[i] = "---";
				}
			}
		}
		if(sit == 3) {
			for (int i = 0; i < B.length; i++) {
				if(B[i].equals(name)) {
					B[i] = "---";
				}
			}
		}
	}
	public void cancle() { //����ϱ� �� �¼� ���� �����ֱ�
		
		System.out.println("�¼� ���� S : 1, A : 2, B: 3 >>");
		int canclesit = scanner.nextInt();
		scanner.nextLine();
		
		
		if(canclesit == 1) {
			System.out.print("S >> ");
			for (int i = 0; i < S.length; i++) {
				System.out.print(S[i] + " ");
			}
		}
		if(canclesit == 2) {
			System.out.print("A >> ");
			for (int i = 0; i < A.length; i++) {
				System.out.print(A[i] + " ");
			}
			
		}
		if(canclesit == 3) {
			System.out.print("B >> ");
			for (int i = 0; i < B.length; i++) {
				System.out.print(B[i] + " ");
			}
			
		}
		
		cancle(canclesit);
	}
	
}































