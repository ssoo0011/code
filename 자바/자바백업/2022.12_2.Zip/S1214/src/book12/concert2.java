package book12;

import java.util.Scanner;

public class concert2 {

	public static void main(String[] args) {
		
		tiket2 tiket2 = new tiket2();
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("��� �ܼ�Ʈ ����ý����Դϴ�~");
		tiket2.array();
		
		
		while (true) {
			System.out.println();
			int menu = tiket2.menu();
			
			if(menu == 1) { //menu = a
				tiket2.sit();
			}
			if(menu == 2) {
				tiket2.Info();
			}
			
			if(menu == 3) {

				tiket2.cancle();

			}if(menu == 4) {
				break;
			}
		}
		
	}

}
