package book12;

import java.util.Scanner;

public class ex {

	public static void main(String[] args) {
		
		String [] S = new String[10];
		Scanner scanner = new Scanner(System.in);

		System.out.println("��� �ܼ�Ʈ ����ý����Դϴ�~");
		
		while (true) {
			System.out.print("���� : 1, ��ȸ : 2, ��� : 3, ������ : 4 >>");
			int a = scanner.nextInt();
			
			System.out.println("�¼� �Է��ϼ���");
			int sit = scanner.nextInt();
			System.out.println("�̸� >>");
			String name = scanner.nextLine();
			System.out.println("��ȣ >>");
			int sitnum = scanner.nextInt();
			
			if(sit == 1) {
				System.out.print("S>> ");
				for (int i = 0; i < S.length; i++) {
					if (S[i] == null) {
						S[i] = "---";
						S[sitnum-1] = name;
						System.out.print(S[i] + " ");
					}
				}
				
			}
	
		}
	}
}
