package book04;

public class Rectangle {

	int x;
	int y;
	int width;
	int height;
	
	public Rectangle(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	public int square() {
		return width * height;
	}
	
	public void show() {
		System.out.println("(" + x + "," + y + ")"
				+ "���� ���̰� " + square()+"�� �簢��");
	}
	
	public boolean contains(Rectangle a) {
		if ((a.x + a.width)<(x + width) &&
			(a.y + a.height)<(y + height)) {
			return true;
		}else {
			return false;
		}
		
	}
}
