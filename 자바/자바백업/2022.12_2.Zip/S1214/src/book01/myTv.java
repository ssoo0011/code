package book01;

public class myTv {

	public static void main(String[] args) {
		
		Tv myTv = new Tv("LG", 2017, 32);
		
		myTv.show();
	}

}
