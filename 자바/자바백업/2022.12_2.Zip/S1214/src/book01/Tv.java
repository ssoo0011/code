package book01;

public class Tv {

	String model;
	int year;
	int inch;
	
	public Tv (String model, int year, int inch) {

		this.model = model;
		this.year = year;
		this.inch = inch;
		
	}
	
	public void show(){

		System.out.println(model + " ���� ����" +  year + "���� " + inch +"��ġ TV");
	}
}

