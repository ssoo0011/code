package action;

import java.util.Scanner;
import action.Action;
import svc.MemberDeleteService;
import svc.MemberRegistService;
import util.ConsoleUtil;
import vo.Member;

public class MemberDeleteAction implements Action{

		@Override
		public void execute(Scanner scanner) throws Exception{
			ConsoleUtil consol = new ConsoleUtil();
			//Member newMember = consol.getNewMember(scanner);
			
			int id = consol.getId("������ ", scanner);
			MemberDeleteService memberDeleteService = new MemberDeleteService(); 
			boolean deleteSuccess = memberDeleteService.deleteMember(id);
			
			if(deleteSuccess) {
				consol.printDeleteSuccessMessage(id);
			}else {
				consol.printDeleteFailMessage(id);
			}
		}
}
