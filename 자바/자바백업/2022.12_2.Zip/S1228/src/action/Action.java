package action;
import java.util.Scanner;

public interface Action {

	 void execute(Scanner scanner) throws Exception;

}
