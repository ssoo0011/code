
public class �ݺ���5 {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		for (int m = 2; m <=9 ; m++) {
			System.out.println(m+"��");
			for (int i = 1; i<=9; i++) {
				System.out.println(m + "x" + i + "=" + (m*i));
			}
		}
	}

}
