package �ݺ���_����;

public class pdf����_5 {

	public static void main(String[] args) {
		
		for (int i = 1 ; i <= 5 ; i++ ) {
//			
//			for (int b = 4; b >=i ; b--) {
//				System.out.print(" ");
//			}
			for (int a = 1 ; a <= i; a ++) {
				System.out.print("*");
			}
//			for (int c = 2 ; c <= i; c ++) {
//				System.out.print("*");
//			}
			System.out.println();
			
			
		}
	}

}
