package �ݺ���_����;

public class å_����2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int sum = 0;
		
		for (int a = 1; a <= 10; a++) {
			sum += a;
			System.out.print(a);
			if (a<=9) System.out.print("+");
			else {
				System.out.print("=");
				System.out.print(sum);
			}
		}
	}

}
