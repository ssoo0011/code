
public class �ݺ���3 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//
//		int i = 1;
//		while(i <=10) {
//			System.out.println(i);
//			i++;
//		}
		
		float a = 0;
		float i = 0.1f;
		while(i <=1f) {
			System.out.println(i);
			
			i += 0.1f;
			
			a += i;
			
		} System.out.println(a);
		
	}

}
