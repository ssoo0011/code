

public class �ݺ���2 {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float b = 0;
		for (float a = 0.1f ; a <= 1.0f ; a+= 0.1f ) {
			System.out.println(a);
			
			b += a;
			
		}System.out.println(b);

	
//		
//		float b = 0;
//		for (float a = 1.0f ; a >= 0.1f ; a-= 0.1f ) {
//			System.out.println(a);
//			b += a;
//			
//		}System.out.println(b);
//		
	}

}
