package pdf����_0;

import java.util.Scanner;

public class pdf����_A {

	public static void main(String[] args) {
		
		while (true) {
		
			Scanner sc = new Scanner(System.in);
			
			System.out.println("���ڸ� �Է��ϼ���");
			int a = sc.nextInt();
			int b = sc.nextInt();
			int c = sc.nextInt();
			
			if (a < b && b < c) { //a<b<c
				System.out.println(c + "," + b + "," + a);
				
			} else if (a <c && c < b) {//a<c<b
				System.out.println(b + "," + c + "," + a);
				
			} else if (b <a && a < c) {//bac
				System.out.println(c + "," + a + "," + b);
				
			} else if (b <c && c < a) {//bca
				System.out.println(a + "," + c + "," + b);
				
			} else if (c <b && b < a) {//cba
				System.out.println(a + "," + b + "," + c);
				
			} else if (c <a && a < b) {//cab
				System.out.println(b + "," + a + "," +c);
				
			} else if (a == b || b == c || c == a ) { 
				System.out.println( "���ڸ� �ٽ� �Է��ϼ���.");
			}
		}


	}

}
