package pdf����_0;

import java.util.Scanner;

public class pdf����_A_2 {

	public static void main(String[] args) {
		
		while (true) {
		
			Scanner sc = new Scanner(System.in);
			
			System.out.println("���ڸ� �Է��ϼ���");
			int a = sc.nextInt();
			int b = sc.nextInt();
			int c = sc.nextInt();
			

			int max = 0, mid = 0, min = 0, temp;
			
			max = a;
			mid = c;
			min = b;
			
			if (max < mid) { 
				temp = mid;
				mid = max;
				max = temp;
				
			}
			if (max < min) {
				temp = min;
				min = max;
				max = temp;
			}
			if (mid < min) {
				temp = mid;
				mid = min;
				min = temp;
			
			} /*System.out.println(max + " " + mid+ " " + min + " ") ;*/
				System.out.printf("%d" + "%d" + "%d" , max , mid, min );
				
		
		}


	}

}
