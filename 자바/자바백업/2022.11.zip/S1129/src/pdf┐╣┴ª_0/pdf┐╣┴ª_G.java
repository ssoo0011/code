package pdf����_0;

import java.util.Scanner;

public class pdf����_G {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("���ڸ� �Է��ϼ���");
		int a = sc.nextInt();
		
		for (int i = 1; i <=a; i++ ) {
			for (int j = a; j >= i; j--)
			System.out.print("*");
			System.out.println("");
		}

	}

}

/*
*****
****
***
**
*
*/