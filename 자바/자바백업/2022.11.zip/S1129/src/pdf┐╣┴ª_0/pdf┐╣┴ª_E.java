
package pdf����_0;
import java.util.Scanner;
public class pdf����_E {

	public static void main(String[] args) {
		
		while(true) {
		
		Scanner sc = new Scanner(System.in);
	
		System.out.println("���ڸ� �Է��ϼ���.(Ȧ��)");
		int a = sc.nextInt();
		
		
		
			if (a % 2 !=0) {
			
				for (int i = 1; i<=(a/2)+1; i++) {
					for (int j = 1; j<=i; j++) {
						System.out.print("*");
					}
					System.out.println("");
				}
				for (int i = 1; i <= (a/2); i++) {
					for (int j = (a/2); j>=i ; j--)
					{
						System.out.print("*");
					}System.out.println("");
				}
			} else {
				System.out.println("Ȧ���� �Է��ϼ���.");
			}
		}

	}

}

/*
*
**
***
****
*****
****
***
**
*
*/
