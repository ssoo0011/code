package pdf����_0;
import java.util.Scanner;
public class pdf����_B {

	public static void main(String[] args) {

		while(true) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("���ڸ� �Է��ϼ���.");
		
		int a = sc.nextInt();
		
		for (int i = 0; i < a ; i ++) {
			
			//i 0 j 0, j 1, j, 2
			//i 1 j 0 j 1 j 2
			//i 2 j 0 1 2
			for (int j = 0; j < a ; j++) {
				
				
				System.out.print("*");
				
			}
			
			System.out.println("");
		}
		
		}
	}

}

