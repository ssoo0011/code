
public class for���� {

	public static void main(String[] args) {
		
		outter :for(int i = 2; i <= 9 ; i++) {
			System.out.println(i + "��");
		
			for (int j = 1; j <= 9; j++) {
				System.out.print (i + "x" + j + "=" + (i*j) + "   ");
				
				if ( j ==8 ) {
					break outter;
				}
			}
			
		} 
		
		System.out.println("break��.");
	}

}
