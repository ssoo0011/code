
public class Q02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 1;
		
		while (true) {
			
			System.out.println(a);
			a++;
			
			if (a == 10) {
				break;
			}
		}
		
			

	}

}
