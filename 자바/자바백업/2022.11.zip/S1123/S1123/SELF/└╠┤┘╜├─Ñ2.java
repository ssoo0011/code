package SELF;

import java.util.Scanner;

public class �̴ٽ�ĥ2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		int a = 0;
		
		while(true) {
		
			System.out.println(a);
			
			a++;
			
			if (a == 5) {
				System.out.println("����");
				break;
			}
		}	
		
		
	}
}