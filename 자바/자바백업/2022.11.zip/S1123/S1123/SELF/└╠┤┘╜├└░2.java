package SELF;

import java.util.Scanner;

public class �̴ٽ���2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Scanner sc = new Scanner(System.in);
		
		
		while(true) {
		
			System.out.print("1~99 ������ ������ �Է��Ͻÿ� >> ");
			int a  = sc.nextInt();
			int ten = a / 10;
			int one = a % 10;
			
			// 33 36 63
			if ( (ten == 3 || ten == 6 || ten == 9) && 
				 (one == 3 || one == 6 || one == 9) ) {
				System.out.println("¦¦");
			}
			
			// 3 9 31
			else if ( (ten == 3 || ten == 6 || ten == 9) ||
					  (one == 3 || one == 6 || one == 9) ) {
				System.out.println("¦");
			}

		}	
	}
}