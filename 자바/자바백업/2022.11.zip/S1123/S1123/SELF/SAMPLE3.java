package SELF;

import java.util.Scanner;

public class SAMPLE3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		while(true) {
		
		System.out.println("���� 3�� �Է�");
		int a  = sc.nextInt();
		int b  = sc.nextInt();
		int c  = sc.nextInt();
		
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
		
		// a>b>c
		if ((a >b &&  b > c) || (c > b && b > a)) { 
			System.out.println("�߰� ���� "+b);
			
			//a>c>b
		} else if ((a >c &&  c > b) || (b > c && c> a)) { 
			System.out.println("�߰� ���� "+c);
			
			//b>a>c
		} else if ((b >a &&  a > c) || (c > a && a > b)) { 
			System.out.println("�߰� ���� "+a);
			
		} else {System.out.println("���ڸ� �ٽ� �Է��ϼ���"); 
		
		}
	}
	}

}
