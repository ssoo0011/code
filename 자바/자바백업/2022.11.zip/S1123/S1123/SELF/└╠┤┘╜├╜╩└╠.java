package SELF;

import java.util.Scanner;

public class �̴ٽý��� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		while(true) {

			System.out.println("1~99 ������ ������ �Է��Ͻÿ� >> ");
			double a  = sc.nextDouble();
			String b  = sc.next();
			double c  = sc.nextDouble();

			if (b .equals("+")) {
				System.out.println(a + c);

			}else if (b .equals("/")) {
				if (c == 0) {
					System.out.println("0���� ���� �� �����ϴ�.");	
				}else {
					System.out.println(a / c);
				}


			}else if (b .equals("*")) {
				System.out.println(a * c);


			}else if (b .equals("-")) {
				System.out.println(a - c);

			}

		}	
	}

}
