package SELF;

public class �̴ٽý���2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		for (int i = 2; i < 10; i++) {
			System.out.println(i + "��");
			for (int j = 1; j < 5; j++) {
				System.out.printf("%d X %d = %d\n", i, j, i*j);
			}
			System.out.println();
		}
	}

}
