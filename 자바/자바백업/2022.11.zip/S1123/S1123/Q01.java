
public class Q01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			int x = 10;
			int y = 20;
			int z = (++x)+(y--);
			System.out.println(z);

	}

}

//���� 31