
public class Q06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float v1= 10f;
 		float v2= v1 / 100;
		
		if(v2 == 0.1f) {
			System.out.println("10%�Դϴ�.");
		}else {
			System.out.println("10%�� �ƴմϴ�.");
		}
		
		int a = 1;
		float b = 1.0f;
		if (a == b) {
			System.out.println("zz");
		} else {
			System.out.println("bv");
		}
	}

}
