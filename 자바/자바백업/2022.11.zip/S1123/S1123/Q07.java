
public class Q07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int lt = 5;
		int lb = 10;
		int h = 7;
//		double area = ((double)lt + (double) lb) * (double)h * 1/2;
		double area = (((double)(lt+lb))*h*1/2);
		System.out.println(area);
	}

}
