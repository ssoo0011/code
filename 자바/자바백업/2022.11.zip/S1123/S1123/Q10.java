
public class Q10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int score = 85;
		String result = (!(score>90))? "��" : "��";
		System.out.println(result);
	}

}
