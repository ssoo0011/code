import java.util.Scanner;
public class Q08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
//		while (true) {
			System.out.println("ù ��° ��");
			double a = sc.nextDouble();
			
//			if(a == 112) {
//				break;
//			}
			
			System.out.println("�� ��° ��");
			double b = sc.nextDouble();
			
		
			
			if(b == 0 || b==0.0) {
				System.out.println("��� : ���Ѵ�");
			}else {
				System.out.println("��� : " + a/b);
			}
//		}
		
		
		
		sc.close();
	}

}
