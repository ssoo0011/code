
public class Q03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int var1 = 5;
		int var2 = 2;
		double var3 = (double)var1 / (double)var2;
		int var4 = (int)(var3 * var2);
		System.out.println(var4);
		
	}

}
