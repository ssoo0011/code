
public class Q09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int v1 = 10;
		int v2 = 3;
		int v3 = 14;
		double v4 = v1 * v1 * Double.parseDouble(v2 + "." + v3);
		
		
		
		
		System.out.println("���� ����: "+ v4);
		

	}

}
