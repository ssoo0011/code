package pdf_����;
import java.util.Scanner;
public class pdf����_A_3�迭��{

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int [3];
		int max = 0;
		int mid = 0;
		int min = 0;
		int temp;

		
		
		
		System.out.println("��� ������ �Է��ϼ���.");

		for (int i = 0; i < 3 ; i++) {

			arr[i] = sc.nextInt();
			}
		
		if (arr[0] > arr[1] && arr [1] > arr[2]) {
			max = arr[0];
			mid = arr[1];
			min = arr[2];
		}
		if (arr[0] > arr[2] && arr [2] > arr[1]) {
			max = arr[0];
			mid = arr[2];
			min = arr[1];
		}
		
		if (arr[1] > arr[2] && arr [2] > arr[0]) {
			max = arr[1];
			mid = arr[2];
			min = arr[0];
		}
		if (arr[1] > arr[0] && arr [0] > arr[2]) {
			max = arr[1];
			mid = arr[0];
			min = arr[2];
		}
		if (arr[2] > arr[1] && arr [1] > arr[0]) {
			max = arr[2];
			mid = arr[1];
			min = arr[0];
		}
		if (arr[2] > arr[0] && arr [0] > arr[1]) {
			max = arr[2];
			mid = arr[0];
			min = arr[1];
		}
		
						
		System.out.print(max + "," + mid + ","  + min);
		sc.close(); 
			
		} 


		
	}

	


