package study;

public class book08 {

	public static void main(String[] args) {

		String ilu = "I Love You";
		int a =ilu.length();

		
		for (int i = 0; i < a+1; i++) { 
			System.out.print(ilu.substring(i));
			System.out.print(ilu.substring(0, i));
			System.out.println();
		}
	}
	
}
