package revise;

public class Member {
	
		private String name;
		private String nation;
		private int age;
		private int height;
		
		

public Member(String name, String nation, int age, int height) {

			this.name = name; //���� �޸𸮿� �ö���ִ� ���ü�� ��Ī�� �� this��
			this.nation = nation;
			this.age = age;
			this.height = height;
		}


	public Member() {
		
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getNation() {
		return nation;
	}


	public void setNation(String nation) {
		this.nation = nation;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public int getHeight() {
		return height;
	}


	public void setHeight(int height) {
		this.height = height;
	}

	
}
