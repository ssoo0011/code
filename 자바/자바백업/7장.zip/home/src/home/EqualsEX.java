package home;

class Point {
	private int x, y;
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
		
	}
	
	public boolean equals(Object ob) {
		Point point = (Point)ob;
		
		if(x == point.x && y == point.y) {
			return true;
		}return false;
	}

}
public class EqualsEX{
	public static void main(String[] args) {

	}	
}

