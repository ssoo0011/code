// 7-2

package action;

import java.util.Scanner;

import action.Action;

public interface Action {
	
	void execute(Scanner scan) throws Exception;
}