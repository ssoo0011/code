package svc;

import ui.MemberUI;
import vo.Member;

public class MemberSearchService {

	public Member searchMemberById(String searchValue) {
		Member member = null;
		
		for (int i = 0; i < MemberUI.memberArray.length; i++) {
			if(MemberUI.memberArray[i].getId() == searchValue) {
				member = MemberUI.memberArray[i];
				break;
			}
		}return member;
	}
		
	public Member[] searchMemberByName(String searchValue) {
		Member[] memArr = null;
		int count = 0;
		Member[]tempArr = new Member[MemberUI.memberArray.length];
		for (int i = 0; i < MemberUI.memberArray.length; i++) {
			if(searchValue.equals(MemberUI.memberArray[i].getName())) {
				tempArr[count++] = MemberUI.memberArray[i];
			}
		}
		
		memArr = new Member[count];
		for (int i = 0; i <count; i++) {
			memArr[i] = tempArr[i];
		}
		return memArr;
	}
 }
	
	
