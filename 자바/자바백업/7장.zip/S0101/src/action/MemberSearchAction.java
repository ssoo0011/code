package action;

import java.util.Scanner;
import svc.MemberSearchService;
import util.ConsoleUtil;
import vo.Member;
import vo.SearchData;

public class MemberSearchAction implements Action{
	@Override
	public void execute(Scanner scanner){
		ConsoleUtil consol = new ConsoleUtil();
		
		SearchData searchData = consol.getSearchData(scanner);
		MemberSearchService memberSearchService = new MemberSearchService();
		
		if(searchData.getSearchCondition().equals("���̵�")) {
			Member member = memberSearchService.searchMemberById(searchData.getSearchValue());
			consol.printSearchMember(member);
		}else if(searchData.getSearchCondition().equals("�̸�")) {
			Member[] memberArr = memberSearchService.searchMemberByName(searchData.getSearchValue());
			consol.printSearchMemberArray(memberArr);
		}
	}
}
