package action;

import java.util.Scanner;
import vo.Member;
import svc.MemberRegistService;
import svc.MemberUpdateService;
import util.ConsoleUtil;

public class MemberUpdateAction implements Action{

	@Override
	public void execute(Scanner scanner) throws Exception{
		ConsoleUtil consol = new ConsoleUtil();
		String id = consol.getId("������", scanner);
		
		MemberUpdateService memberUpdateService = new MemberUpdateService();
		Member oldMember = memberUpdateService.getOldMember(id);
		Member newMember = consol.getNewMember(oldMember, scanner);
		
		boolean updateSuccess = memberUpdateService.updateMember(newMember);
		
		if(updateSuccess) {
			consol.printUpdateSuccessMessage(newMember.getId());
		}else {
			consol.printUpdateFailMessage(newMember.getId());
		}
	}
}
