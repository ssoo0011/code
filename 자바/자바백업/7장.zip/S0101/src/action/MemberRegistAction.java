package action;

import java.util.Scanner;
import vo.Member;
import action.Action;
import svc.MemberRegistService;
import ui.MemberUI;
import util.ConsoleUtil;


public class MemberRegistAction implements Action{
	@Override
	public void execute(Scanner scanner) throws Exception{
		
		ConsoleUtil consol = new ConsoleUtil();
		Member newMember = consol.getNewMember(scanner);
		
		MemberRegistService memberRegistService = new MemberRegistService(); 
		boolean registSuccess = memberRegistService.registMember(newMember);
		
		if(registSuccess) {
			Member[] newMembers = MemberUI.memberArray;
			
			if(newMembers.length < 10) {
				newMember.setId("A00"+newMembers.length);
			}else if(newMembers.length < 100) {
				newMember.setId("A0"+newMembers.length);
//				System.out.println(newMember.getId());
			}
			else if(newMembers.length < 999) {
				newMember.setId("A"+newMembers.length);
//				System.out.println(newMember.getId());
			}
			
			consol.printRegistSuccessMessage(newMember.getName(), newMember.getId());
		
			
		}else {
			consol.printRegistFailMessage(newMember.getName());
		}
	}
}
