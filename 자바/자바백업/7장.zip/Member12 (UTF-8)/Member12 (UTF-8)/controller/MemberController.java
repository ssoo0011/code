package controller;

import action.Action;
import java.util.Scanner;

public class MemberController {
	public void processRequest(Scanner sc, Action action) {
		try {
			action.execute(sc);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
