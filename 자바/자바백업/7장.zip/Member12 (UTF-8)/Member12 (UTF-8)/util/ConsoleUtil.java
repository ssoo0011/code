package util;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



import vo.Member;
import vo.SearchData;

public class ConsoleUtil {

	public Member getNewMember(Scanner sc) {
		
		Member newMember = new Member();
		System.out.println("============새 회원 등록============");
		
//		String name = "";
//		while(true) {
			System.out.print("회원이름 : ");
//			name = sc.next();
//			if(name.length() < 2) {
//				System.out.println("이름을 두 글자 이상 입력하세요.");
//			}else {
//				break;
//			}
//		}
//
//		String pattern = "^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$";
//		String email = "";
//		while(true) {
//			Pattern p = Pattern.compile(email);
//			Matcher m = p.matcher(email);
//			System.out.print("회원이메일 : ");
//			email = sc.nextLine();
//		
//			if (!Pattern.matches(pattern, email)) {
//				System.out.println("이메일을 형식에 맞게 입력하세요.");
//			}else{
//				break;
//			}
//		}
		
//		
//		System.out.print("회원주소 : ");
//		String addr = sc.next();
//		System.out.print("회원취미 : ");
//		String hobby = sc.next();
//		System.out.print("전화번호 : ");
//		String tel = sc.next();
//		System.out.print("회원나이 : ");
//		int age = sc.nextInt();
		
//		newMember.setAddr(addr);
//		newMember.setAge(age);
//		newMember.setEmail(email);
//		newMember.setHobby(hobby);
//		newMember.setName(name);
//		newMember.setTel(tel);
		
		return newMember;
	}
	
	public Member getNewMember(Member oldMember, Scanner sc) {
		Member newMember = new Member();
		System.out.println("============회원 수정======수정수정수정수정======");
//		System.out.print("회원아이디: " + oldMember.getId());
		System.out.println("실행?");
		
//			String email = "";
//			String addr = "";
//			String hobby = "";
//			String tel = "";
//			int age = 0;
		
			System.out.print("회원 이전 이름 : "+oldMember.getName());
			System.out.print("회원 새 이름 : ");
			String name = sc.nextLine();
			if (name.equals("")) {
				name = oldMember.getName();
			}
			
//			System.out.print("회원 이전 이메일 : "+oldMember.getEmail());
//			System.out.print("회원 새 이메일 : ");
//			email = sc.next();
//			
//			System.out.print("회원 이전 주소 : "+oldMember.getAddr());
//			System.out.print("회원 새 주소 : ");
//			addr = sc.next();
//			
//			System.out.print("회원 이전 취미 : "+oldMember.getHobby());
//			System.out.print("회원 새 취미 : ");
//			hobby = sc.next();
//
//			System.out.print("전화 이전 번호 : "+oldMember.getTel());
//			System.out.print("전화 새 번호 : ");
//			tel = sc.next();
//			
//			System.out.print("회원 이전 나이 : "+oldMember.getAge());
//			System.out.print("회원 새 나이 : ");
//			age = sc.nextInt();
//			
//			
//
//			newMember.setId(oldMember.getId());
//			newMember.setAddr(addr);
//			newMember.setAge(age);
//			newMember.setEmail(email);
//			newMember.setHobby(hobby);
			newMember.setName(name);
//			newMember.setTel(tel);
			
			return newMember;
		

	}
	
	public void printUpdateSuccessMessage(String id) {
		System.out.println(id + "회원정보 수정 성공");
	}
	public void printUpdateFailMessage(String id) {
		System.out.println(id + "회원정보 수정 실패");
	}
	
	public void printDeleteSuccessMessage(String id) {
		System.out.println(id + "회원정보 삭제 성공");
	}
	public void printDeleteFailMessage(String id) {
		System.out.println(id + "회원정보 삭제 실패");
	}
	
	public void printRegistSuccessMessage(String name, String id) {
		System.out.println(name + "님의 회원정보 등록 성공");
		System.out.println("회원님의 아이디는" + id + "입니다.");
	}
	public void printRegistFailMessage(String id) {
		System.out.println(id + "회원정보 등록 실패");
	}
	
	public String getId(String msg, Scanner sc) {
		System.out.println(msg + " 아이디 : ");

		
		return sc.nextLine();
	
	}
	
	public void printMemberList(Member[] memberArr) {
		if(memberArr.length==0) {
			System.out.println("등록 된 회원 정보가 없습니다.");
		}else {
			for(int i=0;i<memberArr.length;i++) {
				System.out.println(memberArr[i]);
			}
		}
	}
	
	public void printSearchMember(Member member) {
		if(member == null) {
			System.out.println("검색한 결과가 없습니다.");
		}else {
			System.out.println(member.getId() + "으로 검색한 결과");
			System.out.println(member);
		}
	}
	
	public void printSearchMemberArray(Member[] memberArr) {
		if(memberArr == null) {
			System.out.println("이름으로 검색한 결과가 없습니다.");
		}else {
			System.out.println("이름으로 검색한 결과");
			for(int i=0;i<memberArr.length;i++) {
				System.out.println(memberArr[i]);
			}
		}
	}
	
	public SearchData getSearchData(Scanner sc) {
		System.out.println("검색 조건을 선택하세요");
		System.out.println("- 아이디");
		System.out.println("- 이름");
		System.out.print("검색 조건 : ");
		String searchCondition = sc.next();
		
		String searchValue = null;		
		
		if(searchCondition.equals("아이디") || searchCondition.equals("이름")) {
			System.out.println("검색 할 값 : ");
			searchValue = sc.next();
		}
		
		SearchData searchData = new SearchData();
		searchData.setSearchCondition(searchCondition);
		searchData.setSearchValue(searchValue);
		return searchData;
	}
}













