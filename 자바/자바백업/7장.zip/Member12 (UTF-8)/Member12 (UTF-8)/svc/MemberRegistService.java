package svc;

import ui.MemberUI;
import vo.Member;

public class MemberRegistService {

	public boolean registMember(Member member) {
		boolean registSuccess = true;
		
		for(int i=0;i<MemberUI.memberArray.length;i++) {
			if(MemberUI.memberArray[i].getId() == member.getId()) {
				registSuccess = false;
				break;
			}
		}
		
		if(registSuccess) {
			Member[] tempArr = MemberUI.memberArray;
			MemberUI.memberArray = new Member[MemberUI.memberArray.length+1];
			for(int i=0;i<tempArr.length;i++) {
				MemberUI.memberArray[i] = tempArr[i];
			}
			MemberUI.memberArray[MemberUI.memberArray.length-1] = member;
		}
		return registSuccess;
	}
}




