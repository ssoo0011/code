package svc;

import ui.MemberUI;
import vo.Member;

public class MemberDeleteService {
	
//	public boolean deleteMember(String id) {
//		boolean deleteSuccess = false;
//		int index = -1;
//		
//		for(int i=0; i<MemberUI.memberArray.length; i++) {
//			if(MemberUI.memberArray[i].getId().equals(id)) {
//				index = i;
//			}
//		}
//		
//		if(index != -1) {
//			Member[] tempArr = MemberUI.memberArray ;
//			MemberUI.memberArray = new Member[MemberUI.memberArray.length-1];
//			
//			for(int i=0;i<tempArr.length;i++) {
//				if(i<index) {
//					MemberUI.memberArray[i] = tempArr[i];
//				}else if(i>index) {
//					MemberUI.memberArray[i-1] = tempArr[i];
//				}
//			}
//			deleteSuccess = true;
//		}
//		return deleteSuccess;
//	}
	
	public boolean deleteMember(int num) {
		boolean deleteSuccess = false;
		int index = num-1; // num -1은 삭제하고싶은 아이디의 배열 번호
		
		Member[] tempArr = MemberUI.memberArray ;
		MemberUI.memberArray = new Member[MemberUI.memberArray.length-1];
		
		if(index > tempArr.length) {
			deleteSuccess = false;
		}else {
			for(int i=0;i<tempArr.length;i++) {
				if(i<index) {
					MemberUI.memberArray[i] = tempArr[i];
				}else if(i>index) {
					MemberUI.memberArray[i-1] = tempArr[i];
				}
			}
			deleteSuccess = true;
		}
	return deleteSuccess;
	}
	
}





