package action;

import java.text.Format;
import java.util.Scanner;
import vo.Member;
import svc.MemberRegistService;
import ui.MemberUI;
import util.ConsoleUtil;

public class MemberRegistAction implements Action{
	
	@Override
	public void execute(Scanner sc) throws Exception{
		ConsoleUtil consol = new ConsoleUtil();
		Member newMember = consol.getNewMember(sc);
		
		MemberRegistService memberRegistService = new MemberRegistService();
		boolean registSuccess = memberRegistService.registMember(newMember);
		
		if(registSuccess) {
			int a = MemberUI.memberArray.length;
			Member[] newMembers = MemberUI.memberArray;
			newMember.setId(String.format("A%03d",a));

			consol.printRegistSuccessMessage(newMember.getName(), newMember.getId());
		}else {
			consol.printRegistFailMessage(newMember.getName());
		}
	}
}
