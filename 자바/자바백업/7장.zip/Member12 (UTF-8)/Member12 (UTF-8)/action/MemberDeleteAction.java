package action;

import java.util.Scanner;
import svc.MemberDeleteService;
import ui.MemberUI;
import util.ConsoleUtil;
import vo.Member;

public class MemberDeleteAction implements Action{

	@Override
	public void execute(Scanner sc) throws Exception{
		
		ConsoleUtil consol = new ConsoleUtil();
		String num = consol.getId("삭제할", sc);
		for (int i = 0; i < MemberUI.memberArray.length; i++) {
			System.out.println(MemberUI.memberArray[i]);
		}
		MemberDeleteService memberDeleteService = new MemberDeleteService();
		boolean deteleSuccess = memberDeleteService.deleteMember(Integer.parseInt(num));
		
		if(deteleSuccess) {
			consol.printDeleteSuccessMessage(num);
		}else {
			consol.printDeleteFailMessage(num);
		}
		
	}
}
