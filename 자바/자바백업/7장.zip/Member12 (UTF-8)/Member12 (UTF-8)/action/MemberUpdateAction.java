package action;

import java.util.Scanner;
import svc.MemberUpdateService;
import util.ConsoleUtil;
import vo.Member;

public class MemberUpdateAction implements Action{
	@Override
	public void execute(Scanner sc) throws Exception{
		ConsoleUtil consol = new ConsoleUtil();
		String id = consol.getId("수정할", sc);
		MemberUpdateService memberUpdateService = new MemberUpdateService();
		Member oldMember = memberUpdateService.getOldMember(id);
//		System.out.println(memberUpdateService.getOldMember(id));
		Member newMember = consol.getNewMember(oldMember, sc);
				
		boolean updateSuccess = memberUpdateService.updateMember(newMember);
		
		if(updateSuccess) {
			consol.printUpdateSuccessMessage(newMember.getId());
		}else {
			consol.printUpdateFailMessage(newMember.getId());
		}
		
	}
}
