package book_ex;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student{
	String name;
	String major;
	double score;
	double avr; 
	
	public Student(String name, String major, double score, double avr) {
		this.name = name;
		this.major = major;
		this.score = score;
		this.avr = avr;
		
	}

	@Override
	public String toString() {
		return "�̸� : " + name + ", ���� : " + major + ", ���� : " + score + ", ��� : " + avr + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public double getAvr() {
		return avr;
	}

	public void setAvr(double avr) {
		this.avr = avr;
	}
		
}

public class book05 {

	public static void main(String[] args) {

		
		List<Student> study = new ArrayList<Student>();
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.println("�л� �̸�, �а�, �й�, ���� ����� �Է��ϼ���.");
			System.out.print(">>");
			String name = scanner.next();
			
			if(name.equals("�׸�")) {
				System.out.println("�л� �Է� ����");
				break;
			}
			String major = scanner.next();
			double score = scanner.nextDouble();
			double avr = scanner.nextDouble();
			
			Student student = new Student(name, major, score, avr);
			
			study.add(student);
	
		}
		
		for (int i = 0; i < study.size(); i++) { //�л� ��� ���� ���

//				System.out.println("-------------------------------------------");
				System.out.println(study.get(i));
//				System.out.println("-------------------------------------------");
			}
			
		while(true) {
			int index = -1;
			System.out.print("�˻��� �л� �̸� �Է� >>");
			String name = scanner.next();
			
			if(name.equals("�׸�")) {
				System.out.println("���α׷� ����");
				break;
			}

			for (int i = 0; i < study.size(); i++) {
				if(name.equals(study.get(i).getName())) {
					index = i;
					System.out.println(study.get(i));
				}

			}if(index<0) {
				System.out.println("ã�� �� ���� �̸�");
			}
				
		}

	}

}





















