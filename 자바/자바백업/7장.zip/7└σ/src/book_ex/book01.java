package book_ex;

import java.util.Scanner;
import java.util.Vector;

public class book01 {

	public static void main(String[] args) {
		
		Vector<Integer> num = new Vector<Integer>();
		Scanner scanner = new Scanner(System.in);
		System.out.println("���� �Է� (-1�� �Է��ϸ� ����) >> ");
		int max = 0;
		
			for (int i = 0; i < 5; i++) {
				int inputnum = scanner.nextInt();
				scanner.nextLine();
				num.add(i, inputnum);
				System.out.println(num);
				if (inputnum == -1) {
					num.remove(i);
					System.out.println("-1�� �Է��ϼ̽��ϴ�. �Է��� �����մϴ�.");
					break;
				}
				for (int j = 0; j < num.size(); j++) {
					if(num.get(j) > max) {
						max = num.get(j);
					}
				}
				
			}System.out.println(max);
		
	}

}
