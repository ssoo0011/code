package book_ex;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class book08 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		HashMap<String, Integer>customer = new HashMap<String, Integer>();
		System.out.println(" ***  ����Ʈ ���� ���α׷��Դϴ�  ***");
		
		while (true) {
			System.out.print("\n�̸��� ����Ʈ �Է� >> ");
			String name = scanner.next();
			if (name.equals("�׸�")) {
				System.out.println("���α׷� ����");
				break;
			}
			int point = scanner.nextInt();
			scanner.nextLine();
			
			Set<String> key = customer.keySet();
			Iterator<String> keyit = key.iterator();
				
			if (customer.containsKey(name)) {
				customer.replace(name, customer.get(name)+point);
			}else {
				customer.put(name, point); //�̸�, ����Ʈ �ؽ��ʿ� �ֱ�	
			}
			keyit = key.iterator();
			while (keyit.hasNext()) {
				String name1 = keyit.next();
				Integer val = customer.get(name1); 
				System.out.print("(" + name1 + ", "+ val + ") ");
			
			}
//			System.out.println(customer);
			
		}
	}

}
