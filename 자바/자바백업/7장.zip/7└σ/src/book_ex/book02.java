package book_ex;

import java.util.ArrayList;
import java.util.Scanner;

public class book02 {

	public static void main(String[] args) {

		ArrayList<String> grade = new ArrayList<String>();
		Scanner scanner= new Scanner(System.in);
		int counta = 0;
		int countb = 0;
		int countc = 0;
		int countd = 0;
		int countf = 0;
	
		System.out.print("6���� ������ ��ĭ���� �и��Ͽ� �Է�(A/B/C/D/F) >>>");
		
		for (int i = 0; i < 6; i++) {
			String score = scanner.next();
			grade.add(score);
			
			if (grade.get(i).equals("a")) {
				counta+=1;
				
			}else if(grade.get(i).equals("b")){
				countb+=1;
				
			}else if(grade.get(i).equals("c")){
				countc+=1;
				
			}else if(grade.get(i).equals("d")){
				countd+=1;
				
			}else if(grade.get(i).equals("f")){
				countf+=1;
			}

		}System.out.println(grade);
		double sumscore = (counta*4.0) + (countb*3.0) + (countc*2.0) + (countd*1.0) + (countf*0.0);
		System.out.printf("����� : %.2f", sumscore/6);
//		
		
		
	}

}

//
//if (score.equals("A") || score.equals("A")) {
//	intgrade.add(4.0);
//}else if(score.equals("b") || score.equals("B")) {
//	intgrade.add(3.0);
//}
//else if(score.equals("c") || score.equals("C")) {
//	intgrade.add(2.0);
//}else if(score.equals("d") || score.equals("D")) {
//	intgrade.add(1.0);
//}else if(score.equals("f") || score.equals("F")) {
//	intgrade.add(0.0);
//}