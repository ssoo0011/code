package book_ex;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

class Location{
	

	int sn;//����
	int dw;//�浵
	

	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public int getDw() {
		return dw;
	}

	public void setDw(int dw) {
		this.dw = dw;
	}

	public Location(int sn, int dw) {

		this.sn = sn;
		this.dw = dw;
	}

	@Override
	public String toString() {
		return "\t" + sn + "\t" + dw;
	}
	
}

public class book06 {
	public static void main(String[] args) {
		
		HashMap<String, Location> location = new HashMap<String, Location>(4); //ũ�Ⱑ 4
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("����, �浵, ������ �Է��ϼ���.");
		while (location.size() < 4) {
			System.out.print(">>");
			
			String city = scanner.next();
			
			int sn = scanner.nextInt();	
			int dw = scanner.nextInt();

			System.out.println(sn + " "+ dw);
			location.put(city, new Location(sn, dw)); //�ؽ��ʿ� �� �־��ֱ�
			
			System.out.println("---------------------------------------");
			
		}
		//�ؽøʿ� �ִ� ��� ���� ���
		Set<String> key = location.keySet();
		
		Iterator<String> keyit = key.iterator();
		
		while (keyit.hasNext()) {
			String str = keyit.next();
			Location loca = location.get(str); 
			System.out.println(str + loca);
		}
//		
		
		while (true) {
			System.out.println("���� �̸� >>");
			String search = scanner.next();
			keyit = key.iterator();
			
			if (search.equals("�׸�")) {
				System.out.println("�ý��� ����");
				break;
			}	
			while (keyit.hasNext()) {
				String str = keyit.next();
				Location loca = location.get(str); 
			
				if(search.equals(str)) {
					System.out.println(str + loca);
				}
			}
		}		
	}
}















