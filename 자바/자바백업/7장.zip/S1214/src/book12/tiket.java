package book12;

public class tiket {
	String [] S = new String[10];
	String [] A = new String[10];
	String [] B = new String[10];
	
	public void array() {
		for (int i = 0; i < A.length; i++) {
			S[i] = "---";
			A[i] = "---";
			B[i] = "---";
		}
	}
	
	public int sit(int sit) { //�¼� ���� �����ִ� �޼ҵ�

		if(sit == 1) {
			System.out.print("S>> ");
			for (int i = 0; i < A.length; i++) {
				System.out.print(S[i] + " ");
			}
		}else if(sit == 2) {
			System.out.print("A>> ");
			for (int i = 0; i < A.length; i++) {
					System.out.print(A[i] + " ");
				}
			
		}else if(sit == 3) {
			System.out.print("B>> ");
			for (int i = 0; i < B.length; i++) {
					System.out.print(A[i] + " ");
			}
		}
		
		return sit;		
	
	}
	
	public void name(int sit, String name, int sitnum) {//�̸�/ �¼� �ڸ� �ִ� ����

		if(sit == 1) {
			System.out.print("S>> ");
			for (int i = 0; i < S.length; i++) {
				S[sitnum-1] = name;
				System.out.print(S[i] + " ");
			}
			
		}else if(sit == 2) {
			System.out.print("A>> ");
			for (int i = 0; i < A.length; i++) {
				A[sitnum-1] = name;
				System.out.print(A[i] + " ");
			}
			
		}else if(sit == 3) {
			System.out.print("B>> ");
			for (int i = 0; i < B.length; i++) {
				B[sitnum-1] = name;
				System.out.print(B[i] + " ");
			}
		}
		
	}public void Info() {
		
		System.out.print("S >> ");
		for (int i = 0; i < S.length; i++) {
			System.out.print(S[i] + " ");
		}System.out.println();
		System.out.print("A >> ");
		for (int i = 0; i < A.length; i++) {
			System.out.print(A[i] + " ");
		}System.out.println();
		System.out.print("B >> ");
		for (int i = 0; i < B.length; i++) {
			System.out.print(B[i] + " ");
		}
	}
	
	public void cancle(int sit, String name) {

		if(sit == 1) {
			for (int i = 0; i < S.length; i++) {
				if(S[i].equals(name)) {
					S[i] = "---";
				}
			}
		}
		if(sit == 2) {
			for (int i = 0; i < A.length; i++) {
				if(A[i].equals(name)) {
					A[i] = "---";
				}
			}
		}
		if(sit == 3) {
			for (int i = 0; i < B.length; i++) {
				if(B[i].equals(name)) {
					B[i] = "---";
				}
			}
		}
	}
	public void cancle(int sit) {
		if(sit == 1) {
			System.out.print("S >> ");
			for (int i = 0; i < S.length; i++) {
				System.out.print(S[i] + " ");
			}
		}
		if(sit == 2) {
			System.out.print("A >> ");
			for (int i = 0; i < A.length; i++) {
				System.out.print(A[i] + " ");
			}
			
		}
		if(sit == 31) {
			System.out.print("B >> ");
			for (int i = 0; i < B.length; i++) {
				System.out.print(B[i] + " ");
			}
			
		}
	}
	
}































