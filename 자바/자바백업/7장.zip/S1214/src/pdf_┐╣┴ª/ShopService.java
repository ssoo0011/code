package pdf_����;

public class ShopService {
	private static ShopService instance = new ShopService();
	
	private ShopService() {
		
	}
	public static ShopService getIns() {
		return instance;
	}

}
