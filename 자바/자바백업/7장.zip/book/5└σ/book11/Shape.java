package book11;

public abstract class Shape {
	
}
