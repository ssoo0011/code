package book1;

class MyPoint{
	int x;
	int y;
	
	public MyPoint(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public String toString() {
		return "Point (" + x + " , " + y + ")";
	}
	
	public boolean equals(Object obj) {
		
		MyPoint mp = (MyPoint)obj;
		if (mp.x == x && mp.y == y) 
			return true;
		else 
			return false;
	}
}

public class MyPointEx {

	public static void main(String[] args) {
		
		MyPoint p = new MyPoint(3, 50);
		MyPoint q = new MyPoint(3, 50);
		System.out.println(p);
		
		if(p.equals(q)) 
			System.out.println("���� ��");
		else 
			System.out.println("�ٸ� ��");
	}

}
