package book11;

import java.util.Scanner;

public class calculator {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			System.out.println("�� ������ �����ڸ� �Է��Ͻÿ�(+, -, *, /)");
			
			int a = scanner.nextInt();
			int b = scanner.nextInt();
			String c = scanner.next();
			
			if(c.equals("+")) {
				add add = new add();
				add.setValue(a, b);
				System.out.println(add.calculate());
			}else if(c.equals("-")) {
				sub sub = new sub();
				sub.setValue(a, b);
				System.out.println(sub.calculate());
			}else if(c.equals("*")) {
				mul mul = new mul();
				mul.setValue(a, b);
				System.out.println(mul.calculate());
			}else if(c.equals("/")) {
				div div = new div();
				div.setValue(a, b);
				System.out.println(div.calculate());
			}
		}
		
	}

}
