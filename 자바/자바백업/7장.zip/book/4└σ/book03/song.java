package book03;

public class song {

	String title;
	String artist;
	String country;
	int year;
	
	public song() {
		
	}

	public song(String title, String artist, String country, int year) {
		this.title = title;
		this.artist = artist;
		this.country = country;
		this.year = year;
	}
	
	public void show () {
		System.out.println(year + "�� " + country +
				"������ "+ artist + "�� �θ� "+ title);
	}
	
}
