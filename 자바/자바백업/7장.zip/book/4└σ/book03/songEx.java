package book03;

public class songEx {

	public static void main(String[] args) {
		
		song sing = new song("Dancing Queen", "ABBA", "������", 1978);
		
		sing.show();
	}

}
