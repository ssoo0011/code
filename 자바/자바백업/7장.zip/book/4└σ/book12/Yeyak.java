package book12;

public class Yeyak {
	String sit;
	String name;
	int i;
	
}
