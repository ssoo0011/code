package book10;

import java.util.Scanner;

public class DicApp {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		Dictionary dic = new Dictionary();
		
		
		System.out.println("�ѿ��ܾ� �˻� ���α׷��Դϴ�.");
		
		boolean run = true;
		while(run) {
			
			System.out.println("�ѱ۴ܾ �Է��ϼ���");
			String word = scanner.nextLine();
			
			if (word.equals("�׸�")) {
				break;
			}
			System.out.print(word + "��(��)");
			dic.kor2Eng(word);
			
			
		}
	}

}
