package book02;

public class Grade {
	
	private int math;
	private int science;
	private int eng;

	public Grade(int math, int science, int eng) {
		
		this.math = math;
		this.science = science;
		this.eng = eng;
	}
	
	public int average() {
		
		return (math + science + eng) / 3; 
		
	}

}
