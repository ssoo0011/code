package book08;

public class Phone {
	
	String name;
	String tel;
	
	public Phone() {
		
	}
	public Phone(String name) {
		this.name = name;

	}

	public Phone(String name, String tel) {
		this.name = name;
		this.tel = tel;
	}
	
	
}

