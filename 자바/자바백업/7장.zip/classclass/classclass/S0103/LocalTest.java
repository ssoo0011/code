package S0103;
class OuterClass3{
	private int OuterVar = 10;
	private static int OuterStaticVar = 30;
	
	void printInfo() {
		int localVar = 3;
		final int finalLocal = 5;
		class LocalInnerClass{
			void displayInfo() {
				System.out.println("OuterVar : " + OuterVar);
				System.out.println("OuterStaticVar : " + OuterStaticVar);
				System.out.println("localVar : " + localVar);
				System.out.println("finalLocal : " + finalLocal);
			}
		}
		LocalInnerClass lc = new LocalInnerClass(); //Ŭ���� ����� ��ü �������� ���ο��� ���� ����!
		lc.displayInfo();
	}
}
public class LocalTest {

	public static void main(String[] args) {

		OuterClass3 oc3 = new OuterClass3();
		oc3.printInfo();
	}

}
