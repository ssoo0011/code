package S0103;

public class D05 {

	public static void main(String[] args) {

		
	}

}
