
class PocketBallLocal{
	int size = 100;
	int price = 5000;
	
	public void pocketMethod() {
		int exp = 5000;
		
		class PocketMonster2{
			String name = "�̻��ؾ�";
			int level = 10;
			
			public void getPocketLevel() {
				System.out.println(level);
				System.out.println(exp);
			}
		}
		
		class PocketMonster99{
			String name = "���ڸ�";
			int level = 50;
		}
		
//		PocketMonster2 pm2 = new PocketMonster2();//��ü����
//		pm2.getPocketLevel();
		new PocketMonster2().getPocketLevel();
	}
	
}

public class Inner3 {

	public static void main(String[] args) {

		
	}

}
