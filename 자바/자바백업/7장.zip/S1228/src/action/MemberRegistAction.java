package action;

import java.util.Scanner;
import vo.Member;
import action.Action;
import svc.MemberRegistService;
import util.ConsoleUtil;


public class MemberRegistAction implements Action{
	@Override
	public void execute(Scanner scanner) throws Exception{
		ConsoleUtil consol = new ConsoleUtil();
		
		Member newMember = consol.getNewMember(scanner);
		
		MemberRegistService memberRegistService = new MemberRegistService(); 
		boolean registSuccess = memberRegistService.registMember(newMember);
		
		if(registSuccess) {
			consol.printRegistSuccessMessage(newMember.getId());
		}else {
			consol.printRegistFailMessage(newMember.getId());
		}
	}
}
