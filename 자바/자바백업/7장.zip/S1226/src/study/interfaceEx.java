package study;

import phone.SamsungPhone;

public class interfaceEx {

	public static void main(String[] args) {
		
		SamsungPhone sp = new SamsungPhone();
		sp.printLogo();
		sp.sendCall();
		sp.receiveCall();
		sp.flash();
	}

}
 