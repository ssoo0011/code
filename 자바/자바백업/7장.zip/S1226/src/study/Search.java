package study;

public interface Search {
	void navi(String url);
}
