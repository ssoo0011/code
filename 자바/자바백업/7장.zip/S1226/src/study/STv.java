package study;

public class STv {

	public static void main(String[] args) {

		SmartTv sv = new SmartTv();
		Remotcontrol rc = sv;
		Search s = sv;
		
	}

}
