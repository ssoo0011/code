package study;

public class Audio implements Remotcontrol{
	
	private int volume;
	
	public void turnOn() {
		System.out.println("Audio�� �մϴ�.");
	}
	public void turnOff() {
		System.out.println("Audio�� ���ϴ�.");
	}
	public void setVolume(int volume) {
		if(volume > Remotcontrol.MAX_VOLUME) { 
			this.volume = Remotcontrol.MAX_VOLUME;
		}else if(volume <Remotcontrol.MIN_VOLUME) {
			this.volume = Remotcontrol.MIN_VOLUME;
		}else {
			this.volume = volume;
		}
		System.out.println("���� ������ " + this.volume + "�Դϴ�.");
	}
}
