package study;

public class RemotEx {

	public static void main(String[] args) {
		
		Remotcontrol rc;
		rc = new TV();
		rc = new Audio();

		rc.setVolume(5);
	}

}
