package study;

class MyClass {

	Remotcontrol rc = new TV();
	
	public MyClass() {

	}
	public MyClass(Remotcontrol rc) {
		this.rc = rc;
		rc.turnOn();
		rc.setVolume(9);
	}
	void func() {
		Remotcontrol rc = new Audio();
		rc.turnOn();
		rc.setVolume(3);
	}
	void func2(Remotcontrol rc) {
		rc.turnOn();
		rc.setVolume(7);
	}
 
}

public class MyClassEx{
	public static void main (String[]args) {
		
		System.out.println("1-------------------------------------");
		MyClass mc1 = new MyClass();
		mc1.rc.turnOn();
		mc1.rc.setVolume(5);
		
		System.out.println("2-------------------------------------");
		MyClass mc2 = new MyClass(new Audio());
		
		System.out.println("3-------------------------------------");
		MyClass mc3 = new MyClass();
		mc3.func();
		
		System.out.println("4-------------------------------------");
		MyClass mc4 = new MyClass();
		mc4.func2(new SmartTv());
		
		
		
	}
}
