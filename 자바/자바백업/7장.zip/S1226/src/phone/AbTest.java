package phone;

abstract class Vehicle{
	abstract void transfer();
}

class Car extends Vehicle{
	@Override
	 void transfer() {
		System.out.println("���η� ����մϴ�~");
	}
}

class Ship extends Vehicle{
	@Override
	
	void transfer() {
		System.out.println("�ٴٷ� ����մϴ�.");
	}
}

class Plane extends Vehicle {
	@Override
	void transfer() {
		System.out.println("�ϴ÷� ����մϴ�.");
	}
}

class VehicleUse{
	void showWay(Vehicle v) {
		v.transfer();
	}
}

public class AbTest {

	public static void main(String[] args) {
		
		Car car = new Car();
		Ship ship = new Ship();
		Plane plane = new Plane();
		
		VehicleUse vu = new VehicleUse();
		
		vu.showWay(car); //car.transfer();
		vu.showWay(ship); //ship.transfer();
		vu.showWay(plane); // plane.transfer();
		System.out.println();
	}

}
