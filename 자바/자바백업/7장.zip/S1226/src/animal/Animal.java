package animal;

public abstract class Animal { //abstract  �� �߻�

	public String kind;
	
	public void breathe() {
		System.out.println("���� ���ϴ�.");
	}
	
	public abstract void sound();

//	protected abstract void sound();
	
}
