import java.util.Scanner;
public class test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("ù��° ��:");
		String strNum1 = sc.nextLine();
		
		System.out.print("�ι�° ��:");
		String strNum2 = sc.nextLine();
		
//		System.out.println(strNum1);
//		System.out.println(strNum2);
//		System.out.println(strNum1 + strNum2);
		
		
		
		int num1 = Integer.parseInt(strNum1);
		int num2 = Integer.parseInt(strNum2);
		int result = num1 + num2;
		System.out.println("���� ���: " + result);
		
		
		
//		Scanner sc = new Scanner(System.in);
//		
//		System.out.print("�ƹ� ���̳� �Է��ϼ��� : ");
//		String a = sc.nextLine();
//		String a = sc.next();
//	
//		System.out.print("�ƹ� ���ڳ� �Է��ϼ��� : ");
//		int aaa = sc.nextInt();
//		
//		System.out.println(a);
//		System.out.println(aaa);
		
		
	}

}
