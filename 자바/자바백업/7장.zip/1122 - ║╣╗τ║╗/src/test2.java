
public class test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c1 = 'a';
		char c2 = (char)(c1 + 1);
		System.out.println(c2);
	}

}
