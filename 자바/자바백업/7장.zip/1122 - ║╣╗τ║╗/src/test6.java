
public class test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name= "���ڹ�";
		int age = 25;
		String tel1 = "010", tel2 = "123", tel3 = "4567";
		
//		System.out.println("�̸�: "+ name);
//		System.out.print("���� :" + age +"\n ");
		System.out.printf("��ȭ : %s - %s - %s", tel1, tel2, tel3);
		System.out.println();
	}

}
