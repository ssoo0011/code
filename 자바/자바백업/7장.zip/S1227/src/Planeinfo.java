
public class Planeinfo {

	public static void showPlaneInfo (AirPlane airPlane) {
		System.out.println("�̸� : " + airPlane.getName());
		System.out.println("������ : " + airPlane.getBrand());
		System.out.println("���� : " + airPlane.getPrice());
	}
}
