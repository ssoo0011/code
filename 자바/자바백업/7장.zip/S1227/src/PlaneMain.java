
public class PlaneMain {

	public static void main(String[] args) {
		

		CombatPlane combat = new CombatPlane();
		AirLiner air = new AirLiner();
		
		Planeinfo.showPlaneInfo(combat);
		Planeinfo.showPlaneInfo(air);
	}

}
