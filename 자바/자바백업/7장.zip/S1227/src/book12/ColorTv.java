package book12;

public class ColorTv extends Tv{
	
	int color;
	
	public ColorTv(int size, int color) {
		super(size);
		
		this.color = color;
		
	}
	
	public void printProperty(){
		
		System.out.println(getSize() + "��ġ" + color + "�÷�");
	}

}
