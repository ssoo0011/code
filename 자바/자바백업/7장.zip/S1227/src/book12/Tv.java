package book12;

public class Tv {
	private int size;
	
	public Tv(int size) {
		this.size = size;
	}
	
	protected int getSize() {
		return size;
	}
}
