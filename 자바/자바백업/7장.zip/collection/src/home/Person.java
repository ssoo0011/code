package home;

public class Person {
	
	int age;
	String name;
	String adrr;

	public Person(int age, String name, String addr){
		
		this.age = age;
		this.name = name;
		this.adrr = addr;
	}
	
	@Override
	public String toString() {
		return "���� : " + age + ", �̸� : " + name + ", �ּ� : " + adrr;
	}
	
}
