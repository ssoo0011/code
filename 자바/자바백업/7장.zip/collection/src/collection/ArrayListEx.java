package collection;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class ArrayListEx {

	public static void main(String[] args) {

		List<String> list = new ArrayList<String>(); //��ĳ����
//		ArrayList<String> arr = new ArrayList<String>();
		
		list.add("�ȳ�");
		list.add("hi");
		list.add("ni hao");
		list.add("������~");
		list.add(2, "�ٺ�!");
		
		int n = list.size();
		
		for (int i = 0; i < list.size(); i++) {
			System.out.print(list.get(i));
		}
		System.out.println();
		
		list.remove(2);
		for (int i = 0; i < list.size(); i++) {
			System.out.print(list.get(i));
		}
		
		
	}

}
