package �ǽ�����;

public class Q_14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
