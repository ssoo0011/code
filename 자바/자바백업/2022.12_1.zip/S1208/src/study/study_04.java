package study;

public class study_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
