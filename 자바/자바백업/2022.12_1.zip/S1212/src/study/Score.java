package study;



class Score{ //Ŭ����
	
	String name;
	int Kor;
	int Eng;
	int Math;
	
	Score(){} //������, 


	public static void main(String[]args) {
		
		Score sy;
		sy = new Score();
		sy.name = "���ҿ�";
		sy.Kor = 99;
		sy.Eng = 99;
		sy.Math = 99;
		
		Score sm;
		sm = new Score();
		sm.name = "�輼��";
		
		
	}
	
}
