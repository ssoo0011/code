package study;

public class Rptksrl {

	void start(){
		System.out.println("���α׷� ����!");
	}
	
	int plus(int a, int b){
		return a + b;
	}
	
	int minus(int a, int b) {
		return a - b;
	}
	
	double div(int a, int b) {
		return (double)a / (double)b;
	}
	
	int rhq(int a , int b) {
		return a * b;
	}
	
	int wprhq(int a, int b) {
		return a^b;
	}
	void finish(){
		System.out.println("���α׷� ����!");
	}
	

}
