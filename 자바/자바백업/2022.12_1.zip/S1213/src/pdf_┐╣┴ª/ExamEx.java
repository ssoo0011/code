package pdf_����;

public class ExamEx {

	public static void main(String[] args) {
	
		
		Exam sy = new Exam("���ҿ�", 100, 100, 100, 100, 100);
		Exam sm = new Exam("�輼��", 0, 5, 3, 7, 1);
		
		System.out.println(sy.toString());
		System.out.println();
		System.out.println(sm.toString());
		

	}

}
