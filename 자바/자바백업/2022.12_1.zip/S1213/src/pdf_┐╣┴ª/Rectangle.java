package pdf_����;

public class Rectangle {
	
	int high;
	int wide;
	
	int area() {
		return  wide * high;
	}

}
