package pdf_����;

import java.io.IOException;

public class alphabet {

	public static void main(String[] args)throws IOException{
	
		
		int[][] al = new int[6][5];  //���ĺ� �迭
		for(int i = 0; i < al.length; i++) {
			
			for(int j = 0; j < al.length; j++) {
				
			}
		}
		
		
		
		
		
	}

		
}
