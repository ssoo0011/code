package study;

public class study_06 {

	public static void main(String[] args) {
		
		int [][]score = new int [3][];
		score[0] = new int [4];
		score[1] = new int [2];
		score[2] = new int [3];
		
		
		//int []a = {1, 3, 5, 7};
		int[][] b = {{1, 3, 4},
					 {2, 3},
					 {2, 5, 7, 8}}; //b.length = 3 (���� ����) b[0].length = 3~~~
		
		
		
	}

}
